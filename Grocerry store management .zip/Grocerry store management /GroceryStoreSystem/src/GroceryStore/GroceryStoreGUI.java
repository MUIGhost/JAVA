// package GroceryStore;

// import javax.swing.*;
// import javax.swing.table.DefaultTableModel;
// import java.awt.*;
// import java.text.DecimalFormat;
// import java.util.List;

// public class GroceryStoreGUI {
//     private BillingManager billingManager;
//     private InventoryManager inventoryManager;
//     private JFrame frame;
//     private JTextArea billArea;
//     private JComboBox<String> productComboBox;
//     private JSpinner quantitySpinner;
//     private JTable productTable;
//     private DefaultTableModel tableModel;
//     private JLabel statusLabel;
//     private DecimalFormat df = new DecimalFormat("#0.00");

//     public GroceryStoreGUI() {
//         try {
//             // Test database connection first
//             if (!DatabaseConnection.testConnection()) {
//                 JOptionPane.showMessageDialog(null, 
//                     "Cannot connect to database. Please check your database settings.",
//                     "Database Error", JOptionPane.ERROR_MESSAGE);
//                 System.exit(1);
//             }
            
//             inventoryManager = new InventoryManager();
//             billingManager = new BillingManager();
//             initializeGUI();
//         } catch (Exception e) {
//             JOptionPane.showMessageDialog(null, 
//                 "Error initializing application: " + e.getMessage(),
//                 "Initialization Error", JOptionPane.ERROR_MESSAGE);
//             e.printStackTrace();
//             System.exit(1);
//         }
//     }

//     private void initializeGUI() {
//         frame = new JFrame("Grocery Store Billing System");
//         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//         frame.setSize(1000, 700);
//         frame.setLocationRelativeTo(null);

//         JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
//         mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

//         // Top panel with status
//         statusLabel = new JLabel("System Ready");
//         statusLabel.setForeground(Color.BLUE);
//         mainPanel.add(statusLabel, BorderLayout.NORTH);
        
//         // Split pane for inventory and billing
//         JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
//         splitPane.setDividerLocation(500);
        
//         // Left panel - Inventory
//         JPanel inventoryPanel = new JPanel(new BorderLayout(5, 5));
//         inventoryPanel.setBorder(BorderFactory.createTitledBorder("Inventory"));
        
//         // Create table model with column names
//         tableModel = new DefaultTableModel(
//             new Object[][] {}, 
//             new String[] {"ID", "Name", "Price", "Stock", "Category"}
//         ) {
//             @Override
//             public boolean isCellEditable(int row, int column) {
//                 return false; // Make table read-only
//             }
//         };
        
//         productTable = new JTable(tableModel);
//         JScrollPane tableScrollPane = new JScrollPane(productTable);
//         inventoryPanel.add(tableScrollPane, BorderLayout.CENTER);
        
//         // Refresh button for inventory
//         JButton refreshButton = new JButton("Refresh Inventory");
//         refreshButton.addActionListener(e -> refreshInventory());
//         inventoryPanel.add(refreshButton, BorderLayout.SOUTH);
        
//         // Right panel - Billing
//         JPanel billingPanel = new JPanel(new BorderLayout(5, 5));
//         billingPanel.setBorder(BorderFactory.createTitledBorder("Billing"));
        
//         // Product selection panel
//         JPanel selectionPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        
//         // Populate product combo box
//         List<Product> products = billingManager.getProducts();
//         String[] productStrings = products.stream()
//             .map(p -> p.getProductId() + " - " + p.getName() + " ($" + df.format(p.getPrice()) + ")")
//             .toArray(String[]::new);
        
//         productComboBox = new JComboBox<>(productStrings);
//         quantitySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));

//         selectionPanel.add(new JLabel("Select Product:"));
//         selectionPanel.add(productComboBox);
//         selectionPanel.add(new JLabel("Quantity:"));
//         selectionPanel.add(quantitySpinner);

//         JButton addButton = new JButton("Add to Bill");
//         JButton generateButton = new JButton("Generate Bill");

//         selectionPanel.add(addButton);
//         selectionPanel.add(generateButton);

//         // Bill display area
//         billArea = new JTextArea();
//         billArea.setEditable(false);
//         JScrollPane billScrollPane = new JScrollPane(billArea);

//         billingPanel.add(selectionPanel, BorderLayout.NORTH);
//         billingPanel.add(billScrollPane, BorderLayout.CENTER);
        
//         // Add clear bill button
//         JButton clearButton = new JButton("Clear Bill");
//         clearButton.addActionListener(e -> clearBill());
//         billingPanel.add(clearButton, BorderLayout.SOUTH);
        
//         // Add panels to split pane
//         splitPane.setLeftComponent(inventoryPanel);
//         splitPane.setRightComponent(billingPanel);
        
//         mainPanel.add(splitPane, BorderLayout.CENTER);

//         // Add action listeners
//         addButton.addActionListener(e -> addItemToBill());
//         generateButton.addActionListener(e -> generateBill());

//         frame.add(mainPanel);
        
//         // Load inventory data into table
//         refreshInventory();
        
//         frame.setVisible(true);
//     }
    
//     private void refreshInventory() {
//         try {
//             // Clear existing data
//             tableModel.setRowCount(0);
            
//             // Refresh inventory manager data
//             inventoryManager.refreshInventory();
            
//             // Populate table with fresh data
//             for (Product product : inventoryManager.getAllProducts()) {
//                 tableModel.addRow(new Object[] {
//                     product.getProductId(),
//                     product.getName(),
//                     df.format(product.getPrice()),
//                     product.getStockQuantity(),
//                     product.getCategory()
//                 });
//             }
            
//             // Update status
//             updateStatus("Inventory refreshed successfully", false);
//         } catch (Exception e) {
//             handleException(e);
//         }
//     }

//     private void addItemToBill() {
//         try {
//             String selected = (String) productComboBox.getSelectedItem();
//             if (selected == null) {
//                 throw new GroceryStoreException("No product selected", 
//                                               GroceryStoreException.INVALID_PRODUCT_CODE);
//             }
            
//             String productId = selected.split(" - ")[0];
//             int quantity = (Integer) quantitySpinner.getValue();

//             billingManager.addItemToBill(productId, quantity);
//             billArea.append(selected + " x " + quantity + "\n");
            
//             updateStatus("Item added to bill", false);
//         } catch (Exception e) {
//             handleException(e);
//         }
//     }

//     private void generateBill() {
//         try {
//             double total = billingManager.generateBill();
//             billArea.append("\nTotal Amount: $" + df.format(total) + "\n");
//             billArea.append("--------------------\n");
            
//             // Refresh inventory after bill generation
//             refreshInventory();
            
//             JOptionPane.showMessageDialog(frame, "Bill generated successfully!");
//             updateStatus("Bill generated successfully", false);
//         } catch (Exception e) {
//             handleException(e);
//         }
//     }
    
//     private void clearBill() {
//         try {
//             billingManager.clearBill();
//             billArea.append("Bill cleared\n");
//             billArea.append("--------------------\n");
//             updateStatus("Bill cleared", false);
//         } catch (Exception e) {
//             handleException(e);
//         }
//     }
    
//     private void handleException(Exception e) {
//         String errorMessage;
//         String errorTitle;
        
//         if (e instanceof GroceryStoreException) {
//             GroceryStoreException gse = (GroceryStoreException) e;
//             errorMessage = gse.getMessage();
//             errorTitle = gse.getErrorType();
//             updateStatus("Error: " + errorTitle + " - " + errorMessage, true);
//         } else {
//             errorMessage = "Unexpected error: " + e.getMessage();
//             errorTitle = "System Error";
//             updateStatus("System Error: " + e.getMessage(), true);
//         }
        
//         JOptionPane.showMessageDialog(frame, errorMessage, errorTitle, JOptionPane.ERROR_MESSAGE);
//         e.printStackTrace();
//     }
    
//     private void updateStatus(String message, boolean isError) {
//         statusLabel.setText(message);
//         statusLabel.setForeground(isError ? Color.RED : Color.BLUE);
//     }

//     public static void main(String[] args) {
//         try {
//             // Set look and feel to system default
//             UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
//         } catch (Exception e) {
//             e.printStackTrace();
//         }
        
//         SwingUtilities.invokeLater(() -> new GroceryStoreGUI());
//     }
// }
