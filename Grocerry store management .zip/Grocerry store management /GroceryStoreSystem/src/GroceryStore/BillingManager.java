package GroceryStore;

import java.sql.*;
import java.util.*;

public class BillingManager {
    private InventoryManager inventoryManager;
    private List<BillItem> currentBill;

   // Updated constructor
   public BillingManager(InventoryManager inventoryManager) {
    this.inventoryManager = inventoryManager;
    currentBill = new ArrayList<>();
}

    public void addItemToBill(String productId, int quantity) {
        try {
            // Check if product exists and has sufficient stock
            Product product = inventoryManager.getProduct(productId);
            
            if (!inventoryManager.checkStock(productId, quantity)) {
                throw new GroceryStoreException(
                    "Insufficient stock for product: " + product.getName() + 
                    ". Available: " + product.getStockQuantity(),
                    GroceryStoreException.OUT_OF_STOCK
                );
            }
            
            // Add to current bill
            currentBill.add(new BillItem(product, quantity));
            
        } catch (GroceryStoreException e) {
            throw e; // Re-throw our custom exceptions
        } catch (Exception e) {
            throw new GroceryStoreException(
                "Error adding item to bill: " + e.getMessage(),
                e, GroceryStoreException.TRANSACTION_ERROR
            );
        }
    }

// Replace the generateBill method with this optimized version that handles transactions better

public double generateBill() {
    if (currentBill.isEmpty()) {
        throw new GroceryStoreException(
            "No items in the bill",
            GroceryStoreException.TRANSACTION_ERROR
        );
    }

    double totalAmount = 0;
    Connection conn = null;
    try {
        conn = DatabaseConnection.getConnection();
        
        // Disable auto-commit to manage transaction manually
        conn.setAutoCommit(false);
        
        // Set transaction isolation level to READ_COMMITTED to reduce lock contention
        conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);

        // Create new bill
        String billSql = "INSERT INTO bills (total_amount) VALUES (?)";
        int billId;
        
        try (PreparedStatement pstmt = conn.prepareStatement(billSql, Statement.RETURN_GENERATED_KEYS)) {
            totalAmount = currentBill.stream()
                .mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity())
                .sum();
            
            pstmt.setDouble(1, totalAmount);
            pstmt.executeUpdate();

            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) {
                    billId = rs.getInt(1);
                } else {
                    throw new SQLException("Failed to get bill ID");
                }
            }
        }

        // Add bill items and update stock with batch processing for better performance
        addBillItemsBatch(conn, billId);
        updateStockBatch(conn);

        // Commit the transaction
        conn.commit();
        currentBill.clear();
        return totalAmount;

    } catch (SQLException e) {
        try {
            if (conn != null) conn.rollback();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        throw new GroceryStoreException(
            "Database error generating bill: " + e.getMessage(),
            e, GroceryStoreException.DATABASE_CONNECTION_ERROR
        );
    } catch (GroceryStoreException e) {
        try {
            if (conn != null) conn.rollback();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        throw e; // Re-throw our custom exceptions
    } finally {
        try {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
}

// Add these new methods for batch processing

private void addBillItemsBatch(Connection conn, int billId) throws SQLException {
    String sql = "INSERT INTO bill_items (bill_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)";
    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
        for (BillItem item : currentBill) {
            pstmt.setInt(1, billId);
            pstmt.setString(2, item.getProduct().getProductId());
            pstmt.setInt(3, item.getQuantity());
            pstmt.setDouble(4, item.getProduct().getPrice());
            pstmt.setDouble(5, item.getProduct().getPrice() * item.getQuantity());
            pstmt.addBatch();
        }
        pstmt.executeBatch();
    }
}

private void updateStockBatch(Connection conn) throws SQLException, GroceryStoreException {
    // First check if we have enough stock for all items
    for (BillItem item : currentBill) {
        Product product = item.getProduct();
        if (product.getStockQuantity() < item.getQuantity()) {
            throw new GroceryStoreException(
                "Insufficient stock for product: " + product.getName() + 
                ". Available: " + product.getStockQuantity(),
                GroceryStoreException.OUT_OF_STOCK
            );
        }
    }
    
    // Update database with batch processing
    String sql = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?";
    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
        for (BillItem item : currentBill) {
            pstmt.setInt(1, item.getQuantity());
            pstmt.setString(2, item.getProduct().getProductId());
            pstmt.addBatch();
            
            // Update local cache
            Product product = item.getProduct();
            product.setStockQuantity(product.getStockQuantity() - item.getQuantity());
        }
        pstmt.executeBatch();
    }
}

    private void addBillItem(Connection conn, int billId, BillItem item) throws SQLException {
        String sql = "INSERT INTO bill_items (bill_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, billId);
            pstmt.setString(2, item.getProduct().getProductId());
            pstmt.setInt(3, item.getQuantity());
            pstmt.setDouble(4, item.getProduct().getPrice());
            pstmt.setDouble(5, item.getProduct().getPrice() * item.getQuantity());
            pstmt.executeUpdate();
        }
    }

    public List<Product> getProducts() {
        return inventoryManager.getAllProducts();
    }
    
    public List<BillItem> getCurrentBillItems() {
        return new ArrayList<>(currentBill);
    }
    
    public void clearBill() {
        currentBill.clear();
    }
    
    public double getCurrentBillTotal() {
        return currentBill.stream()
            .mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity())
            .sum();
    }

    public static class BillItem {
        private Product product;
        private int quantity;

        public BillItem(Product product, int quantity) {
            this.product = product;
            this.quantity = quantity;
        }

        public Product getProduct() { return product; }
        public int getQuantity() { return quantity; }
    }
}
