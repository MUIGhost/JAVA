package GroceryStore;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.awt.image.BufferedImage;

// For PDF generation
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EnhancedGroceryStoreGUI {
    // Managers
    private BillingManager billingManager;
    private InventoryManager inventoryManager;
    
    // Main components
    private JFrame frame;
    private JSplitPane splitPane;
    private JTabbedPane tabbedPane;
    
    // Inventory components
    private JTable productTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JComboBox<String> categoryFilter;
    
    // Billing components
    private JTable billTable;
    private DefaultTableModel billTableModel;
    private JComboBox<String> productComboBox;
    private JSpinner quantitySpinner;
    private JLabel totalLabel;
    
    // Status components
    private JPanel statusPanel;
    private JLabel statusLabel;
    private JProgressBar progressBar;
    
    // Reports components
    private JPanel salesChartPanel;
    private JPanel inventoryChartPanel;
    private JComboBox<String> dateRangeCombo;
    private JComboBox<String> reportCategoryCombo;
    
    // Formatting
    private DecimalFormat df = new DecimalFormat("#0.00");
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    // Colors and styling
    private final Color PRIMARY_COLOR = new Color(25, 118, 210);
    private final Color SECONDARY_COLOR = new Color(66, 165, 245);
    private final Color SUCCESS_COLOR = new Color(76, 175, 80);
    private final Color ERROR_COLOR = new Color(244, 67, 54);
    private final Color WARNING_COLOR = new Color(255, 152, 0);
    private final java.awt.Font HEADER_FONT = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14);
    private final java.awt.Font REGULAR_FONT = new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 12);

    public EnhancedGroceryStoreGUI() {
        try {
            // Set look and feel to system default
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            
            // Test database connection first
            if (!DatabaseConnection.testConnection()) {
                showErrorDialog("Cannot connect to database. Please check your database settings.", "Database Error");
                System.exit(1);
            }
            
            inventoryManager = new InventoryManager();
            billingManager = new BillingManager(inventoryManager);
            initializeGUI();
        } catch (Exception e) {
            showErrorDialog("Error initializing application: " + e.getMessage(), "Initialization Error");
            e.printStackTrace();
            System.exit(1);
        }
    }

    private void initializeGUI() {
        // Create main frame
        frame = new JFrame("Grocery Store Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200, 800);
        frame.setLocationRelativeTo(null);
        frame.setIconImage(createImageIcon("/icons/store.png", "Store Icon").getImage());

        // Create main panel with border layout
        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Create tabbed pane for different sections
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(HEADER_FONT);
        
        // Create inventory panel
        JPanel inventoryPanel = createInventoryPanel();
        tabbedPane.addTab("Inventory", createImageIcon("/icons/inventory.png", "Inventory"), inventoryPanel);
        
        // Create billing panel
        JPanel billingPanel = createBillingPanel();
        tabbedPane.addTab("Billing", createImageIcon("/icons/billing.png", "Billing"), billingPanel);
        
        // Create reports panel
        JPanel reportsPanel = createReportsPanel();
        tabbedPane.addTab("Reports", createImageIcon("/icons/reports.png", "Reports"), reportsPanel);
        
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        // Create status panel
        statusPanel = createStatusPanel();
        mainPanel.add(statusPanel, BorderLayout.SOUTH);
        
        // Add keyboard shortcuts
        setupKeyboardShortcuts();
        
        frame.add(mainPanel);
        frame.setVisible(true);
        
        // Load initial data
        refreshInventory();
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        
        JLabel titleLabel = new JLabel("Grocery Store Management System");
        titleLabel.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.setOpaque(false);
        
        // REMOVED: Settings and Help buttons as requested
        JButton logoutButton = createStyledButton("Logout", "/icons/logout.png");
        logoutButton.addActionListener(e -> logout());
        
        rightPanel.add(logoutButton);
        
        headerPanel.add(rightPanel, BorderLayout.EAST);
        
        return headerPanel;
    }
    
    private JPanel createInventoryPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Create toolbar for inventory actions
        JPanel toolbarPanel = new JPanel(new BorderLayout());
        
        // Left side of toolbar - search and filter
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(20);
        searchField.putClientProperty("JTextField.placeholderText", "Search products...");
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                filterInventoryTable();
            }
        });
        
        JLabel categoryLabel = new JLabel("Category:");
        categoryLabel.setFont(REGULAR_FONT);
        
        categoryFilter = new JComboBox<>(new String[]{"All Categories", "Grains", "Dairy", "Bakery", "Vegetables"});
        categoryFilter.setFont(REGULAR_FONT);
        categoryFilter.addActionListener(e -> filterInventoryTable());
        
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(categoryLabel);
        searchPanel.add(categoryFilter);
        
        // Right side of toolbar - action buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton addProductButton = createStyledButton("Add Product", "/icons/add.png");
        addProductButton.addActionListener(e -> showAddProductDialog());
        
        JButton restockButton = createStyledButton("Restock", "/icons/restock.png");
        restockButton.addActionListener(e -> showRestockDialog());
        
        JButton refreshButton = createStyledButton("Refresh", "/icons/refresh.png");
        refreshButton.addActionListener(e -> refreshInventory());
        
        actionPanel.add(addProductButton);
        actionPanel.add(restockButton);
        actionPanel.add(refreshButton);
        
        toolbarPanel.add(searchPanel, BorderLayout.WEST);
        toolbarPanel.add(actionPanel, BorderLayout.EAST);
        
        panel.add(toolbarPanel, BorderLayout.NORTH);
        
        // Create table model with column names
        tableModel = new DefaultTableModel(
            new Object[][] {}, 
            new String[] {"ID", "Name", "Price", "Stock", "Category", "Status"}
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 2) return Double.class; // Price column
                if (columnIndex == 3) return Integer.class; // Stock column
                return String.class;
            }
        };
        
        productTable = new JTable(tableModel);
        productTable.setFont(REGULAR_FONT);
        productTable.setRowHeight(30);
        productTable.setShowGrid(true);
        productTable.setGridColor(new Color(230, 230, 230));
        productTable.getTableHeader().setFont(HEADER_FONT);
        productTable.getTableHeader().setBackground(SECONDARY_COLOR);
        productTable.getTableHeader().setForeground(Color.WHITE);
        
        // Set column widths
        TableColumnModel columnModel = productTable.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(80);  // ID
        columnModel.getColumn(1).setPreferredWidth(200); // Name
        columnModel.getColumn(2).setPreferredWidth(100); // Price
        columnModel.getColumn(3).setPreferredWidth(100); // Stock
        columnModel.getColumn(4).setPreferredWidth(120); // Category
        columnModel.getColumn(5).setPreferredWidth(100); // Status
        
        // Custom renderer for stock levels
        columnModel.getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                int stock = (Integer) value;
                if (stock <= 10) {
                    c.setForeground(ERROR_COLOR);
                    c.setFont(REGULAR_FONT.deriveFont(java.awt.Font.BOLD));
                } else if (stock <= 30) {
                    c.setForeground(WARNING_COLOR);
                } else {
                    c.setForeground(SUCCESS_COLOR);
                }
                
                return c;
            }
        });
        
        // Custom renderer for status column
        columnModel.getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                String status = (String) value;
                if ("Low Stock".equals(status)) {
                    c.setForeground(ERROR_COLOR);
                } else if ("Medium Stock".equals(status)) {
                    c.setForeground(WARNING_COLOR);
                } else {
                    c.setForeground(SUCCESS_COLOR);
                }
                
                return c;
            }
        });
        
        // Add sorting capability
        productTable.setAutoCreateRowSorter(true);
        
        // Add selection listener
        productTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && productTable.getSelectedRow() != -1) {
                int selectedRow = productTable.getSelectedRow();
                String productId = (String) productTable.getValueAt(selectedRow, 0);
                // You could show product details here
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(productTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Add summary panel at bottom
        JPanel summaryPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        summaryPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        
        JLabel totalProductsLabel = new JLabel("Total Products: 0");
        totalProductsLabel.setFont(REGULAR_FONT);
        
        JLabel lowStockLabel = new JLabel("Low Stock Items: 0");
        lowStockLabel.setFont(REGULAR_FONT);
        lowStockLabel.setForeground(ERROR_COLOR);
        
        summaryPanel.add(totalProductsLabel);
        summaryPanel.add(Box.createHorizontalStrut(20));
        summaryPanel.add(lowStockLabel);
        
        panel.add(summaryPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createBillingPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Create split pane for product selection and bill
        splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(400);
        splitPane.setDividerSize(5);
        splitPane.setBorder(BorderFactory.createEmptyBorder());
        
        // Left panel - Product selection
        JPanel selectionPanel = new JPanel(new BorderLayout(0, 10));
        selectionPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(0, 0, 0, 10),
            BorderFactory.createTitledBorder(BorderFactory.createLineBorder(SECONDARY_COLOR), "Add Products")
        ));
        
        // Product selection form
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        JLabel productLabel = new JLabel("Select Product:");
        productLabel.setFont(REGULAR_FONT);
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(productLabel, gbc);
        
        // Populate product combo box
        List<Product> products = billingManager.getProducts();
        String[] productStrings = products.stream()
            .map(p -> p.getProductId() + " - " + p.getName() + " ($" + df.format(p.getPrice()) + ")")
            .toArray(String[]::new);
        
        productComboBox = new JComboBox<>(productStrings);
        productComboBox.setFont(REGULAR_FONT);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        formPanel.add(productComboBox, gbc);
        
        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setFont(REGULAR_FONT);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        formPanel.add(quantityLabel, gbc);
        
        quantitySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        quantitySpinner.setFont(REGULAR_FONT);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        formPanel.add(quantitySpinner, gbc);
        
        JButton addButton = createStyledButton("Add to Bill", "/icons/add_to_cart.png");
        addButton.addActionListener(e -> addItemToBill());
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        formPanel.add(addButton, gbc);
        
        selectionPanel.add(formPanel, BorderLayout.NORTH);
        
        // Product quick selection grid
        JPanel quickSelectPanel = new JPanel(new BorderLayout());
        quickSelectPanel.setBorder(BorderFactory.createTitledBorder("Quick Select"));
        
        // Create a grid of popular products for quick selection
        JPanel productGrid = new JPanel(new GridLayout(0, 2, 5, 5));
        
        for (int i = 0; i < Math.min(6, products.size()); i++) {
            Product product = products.get(i);
            JButton productButton = new JButton(product.getName());
            productButton.setFont(REGULAR_FONT);
            productButton.setIcon(createImageIcon("/icons/product.png", "Product"));
            productButton.setHorizontalAlignment(SwingConstants.LEFT);
            productButton.addActionListener(e -> {
                productComboBox.setSelectedItem(product.getProductId() + " - " + product.getName() + " ($" + df.format(product.getPrice()) + ")");
                quantitySpinner.setValue(1);
            });
            productGrid.add(productButton);
        }
        
        quickSelectPanel.add(productGrid, BorderLayout.CENTER);
        selectionPanel.add(quickSelectPanel, BorderLayout.CENTER);
        
        // Right panel - Bill
        JPanel billPanel = new JPanel(new BorderLayout(0, 10));
        billPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(0, 10, 0, 0),
            BorderFactory.createTitledBorder(BorderFactory.createLineBorder(SECONDARY_COLOR), "Current Bill")
        ));
        
        // Bill table
        billTableModel = new DefaultTableModel(
            new Object[][] {}, 
            new String[] {"Product", "Price", "Quantity", "Subtotal"}
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 1 || columnIndex == 3) return Double.class;
                if (columnIndex == 2) return Integer.class;
                return String.class;
            }
        };
        
        billTable = new JTable(billTableModel);
        billTable.setFont(REGULAR_FONT);
        billTable.setRowHeight(30);
        billTable.setShowGrid(true);
        billTable.setGridColor(new Color(230, 230, 230));
        billTable.getTableHeader().setFont(HEADER_FONT);
        billTable.getTableHeader().setBackground(SECONDARY_COLOR);
        billTable.getTableHeader().setForeground(Color.WHITE);
        
        // Set column widths
        TableColumnModel billColumnModel = billTable.getColumnModel();
        billColumnModel.getColumn(0).setPreferredWidth(200); // Product
        billColumnModel.getColumn(1).setPreferredWidth(80);  // Price
        billColumnModel.getColumn(2).setPreferredWidth(80);  // Quantity
        billColumnModel.getColumn(3).setPreferredWidth(100); // Subtotal
        
        JScrollPane billScrollPane = new JScrollPane(billTable);
        billScrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        billPanel.add(billScrollPane, BorderLayout.CENTER);
        
        // Bill actions panel
        JPanel billActionsPanel = new JPanel(new BorderLayout());
        
        // Total amount
        JPanel totalPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        totalLabel = new JLabel("Total: $0.00");
        totalLabel.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 16));
        totalPanel.add(totalLabel);
        
        // Action buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton clearButton = createStyledButton("Clear", "/icons/clear.png");
        clearButton.addActionListener(e -> clearBill());
        
        JButton generateButton = createStyledButton("Generate Bill", "/icons/checkout.png");
        generateButton.addActionListener(e -> generateBillPDF());
        
        buttonPanel.add(clearButton);
        buttonPanel.add(generateButton);
        
        billActionsPanel.add(totalPanel, BorderLayout.NORTH);
        billActionsPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        billPanel.add(billActionsPanel, BorderLayout.SOUTH);
        
        // Add panels to split pane
        splitPane.setLeftComponent(selectionPanel);
        splitPane.setRightComponent(billPanel);
        
        panel.add(splitPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createReportsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Create tabs for different reports
        JTabbedPane reportsTabs = new JTabbedPane();
        reportsTabs.setFont(REGULAR_FONT);
        
        // Sales report panel
        JPanel salesPanel = new JPanel(new BorderLayout());
        salesPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Date range selection
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        datePanel.add(new JLabel("Date Range:"));
        dateRangeCombo = new JComboBox<>(new String[]{
            "Today", "Yesterday", "Last 7 Days", "Last 30 Days", "This Month", "Last Month", "Custom..."
        });
        datePanel.add(dateRangeCombo);
        
        JButton generateReportButton = createStyledButton("Generate Report", "/icons/report.png");
        generateReportButton.addActionListener(e -> generateSalesReport());
        datePanel.add(generateReportButton);
        
        salesPanel.add(datePanel, BorderLayout.NORTH);
        
        // Sales chart panel
        salesChartPanel = new JPanel();
        salesChartPanel.setBackground(Color.WHITE);
        salesChartPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        salesChartPanel.setLayout(new BorderLayout());
        
        JLabel chartPlaceholder = new JLabel("Sales Chart Will Appear Here", SwingConstants.CENTER);
        chartPlaceholder.setFont(new java.awt.Font("Segoe UI", java.awt.Font.ITALIC, 14));
        chartPlaceholder.setForeground(Color.GRAY);
        salesChartPanel.add(chartPlaceholder, BorderLayout.CENTER);
        
        salesPanel.add(salesChartPanel, BorderLayout.CENTER);
        
        // Inventory report panel
        JPanel inventoryReportPanel = new JPanel(new BorderLayout());
        inventoryReportPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Category filter
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Category:"));
        reportCategoryCombo = new JComboBox<>(new String[]{
            "All Categories", "Grains", "Dairy", "Bakery", "Vegetables"
        });
        filterPanel.add(reportCategoryCombo);
        
        JButton exportButton = createStyledButton("Export to CSV", "/icons/export.png");
        exportButton.addActionListener(e -> exportInventoryToCSV());
        filterPanel.add(exportButton);
        
        JButton viewReportButton = createStyledButton("View Report", "/icons/view.png");
        viewReportButton.addActionListener(e -> viewInventoryReport());
        filterPanel.add(viewReportButton);
        
        inventoryReportPanel.add(filterPanel, BorderLayout.NORTH);
        
        // Inventory chart panel
        inventoryChartPanel = new JPanel();
        inventoryChartPanel.setBackground(Color.WHITE);
        inventoryChartPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        inventoryChartPanel.setLayout(new BorderLayout());
        
        JLabel inventoryChartPlaceholder = new JLabel("Inventory Chart Will Appear Here", SwingConstants.CENTER);
        inventoryChartPlaceholder.setFont(new java.awt.Font("Segoe UI", java.awt.Font.ITALIC, 14));
        inventoryChartPlaceholder.setForeground(Color.GRAY);
        inventoryChartPanel.add(inventoryChartPlaceholder, BorderLayout.CENTER);
        
        inventoryReportPanel.add(inventoryChartPanel, BorderLayout.CENTER);
        
        // Add tabs
        reportsTabs.addTab("Sales Report", createImageIcon("/icons/sales.png", "Sales"), salesPanel);
        reportsTabs.addTab("Inventory Report", createImageIcon("/icons/inventory_report.png", "Inventory"), inventoryReportPanel);
        
        panel.add(reportsTabs, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        
        statusLabel = new JLabel("System Ready");
        statusLabel.setFont(REGULAR_FONT);
        
        progressBar = new JProgressBar();
        progressBar.setStringPainted(true);
        progressBar.setVisible(false);
        
        panel.add(statusLabel, BorderLayout.WEST);
        panel.add(progressBar, BorderLayout.EAST);
        
        return panel;
    }
    
    private JButton createStyledButton(String text, String iconPath) {
        JButton button = new JButton(text);
        button.setFont(REGULAR_FONT);
        
        if (iconPath != null) {
            button.setIcon(createImageIcon(iconPath, text));
        }
        
        return button;
    }
    
    private ImageIcon createImageIcon(String path, String description) {
        // This is a placeholder - in a real application, you would load actual icons
        // For this example, we'll return a colored square as a placeholder
        int size = 16;
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = image.createGraphics();
        
        // Different colors based on icon type
        if (path.contains("add")) {
            g2d.setColor(SUCCESS_COLOR);
        } else if (path.contains("error") || path.contains("delete")) {
            g2d.setColor(ERROR_COLOR);
        } else if (path.contains("warning")) {
            g2d.setColor(WARNING_COLOR);
        } else {
            g2d.setColor(PRIMARY_COLOR);
        }
        
        g2d.fillRect(0, 0, size, size);
        g2d.dispose();
        
        return new ImageIcon(image, description);
    }
    
    private void setupKeyboardShortcuts() {
        // Add keyboard shortcuts
        KeyStroke refreshKey = KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0);
        KeyStroke addItemKey = KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_DOWN_MASK);
        KeyStroke generateBillKey = KeyStroke.getKeyStroke(KeyEvent.VK_G, InputEvent.CTRL_DOWN_MASK);
        KeyStroke clearBillKey = KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_DOWN_MASK);
        
        // Map actions to the frame's root pane
        JRootPane rootPane = frame.getRootPane();
        InputMap inputMap = rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap actionMap = rootPane.getActionMap();
        
        inputMap.put(refreshKey, "refresh");
        inputMap.put(addItemKey, "addItem");
        inputMap.put(generateBillKey, "generateBill");
        inputMap.put(clearBillKey, "clearBill");
        
        actionMap.put("refresh", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshInventory();
            }
        });
        
        actionMap.put("addItem", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addItemToBill();
            }
        });
        
        actionMap.put("generateBill", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateBillPDF();
            }
        });
        
        actionMap.put("clearBill", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearBill();
            }
        });
    }
    
    private void refreshInventory() {
        // Show progress
        updateStatus("Refreshing inventory...", false);
        showProgress(true);
        
        // Use SwingWorker to perform database operations in background
        SwingWorker<List<Product>, Void> worker = new SwingWorker<List<Product>, Void>() {
            @Override
            protected List<Product> doInBackground() throws Exception {
                // Simulate network delay
                Thread.sleep(500);
                inventoryManager.refreshInventory();
                return inventoryManager.getAllProducts();
            }
            
            @Override
            protected void done() {
                try {
                    List<Product> products = get();
                    
                    // Clear existing data
                    tableModel.setRowCount(0);
                    
                    // Count low stock items
                    int lowStockCount = 0;
                    
                    // Populate table with fresh data
                    for (Product product : products) {
                        String status;
                        if (product.getStockQuantity() <= 10) {
                            status = "Low Stock";
                            lowStockCount++;
                        } else if (product.getStockQuantity() <= 30) {
                            status = "Medium Stock";
                        } else {
                            status = "In Stock";
                        }
                        
                        tableModel.addRow(new Object[] {
                            product.getProductId(),
                            product.getName(),
                            product.getPrice(),
                            product.getStockQuantity(),
                            product.getCategory(),
                            status
                        });
                    }
                    
                    // Update summary labels
                    JPanel summaryPanel = (JPanel) ((JPanel) productTable.getParent().getParent().getParent()).getComponent(2);
                    JLabel totalProductsLabel = (JLabel) summaryPanel.getComponent(0);
                    JLabel lowStockLabel = (JLabel) summaryPanel.getComponent(2);
                    
                    totalProductsLabel.setText("Total Products: " + products.size());
                    lowStockLabel.setText("Low Stock Items: " + lowStockCount);
                    
                    // Update status
                    updateStatus("Inventory refreshed successfully", false);
                    showProgress(false);
                    
                } catch (InterruptedException | ExecutionException e) {
                    handleException(e);
                    showProgress(false);
                }
            }
        };
        
        worker.execute();
    }
    
    private void filterInventoryTable() {
        String searchText = searchField.getText().toLowerCase();
        String category = (String) categoryFilter.getSelectedItem();
        
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        productTable.setRowSorter(sorter);
        
        RowFilter<DefaultTableModel, Object> rowFilter = new RowFilter<DefaultTableModel, Object>() {
            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Object> entry) {
                boolean matchesSearch = false;
                boolean matchesCategory = true;
                
                // Check if matches search text
                if (searchText.isEmpty()) {
                    matchesSearch = true;
                } else {
                    for (int i = 0; i < entry.getValueCount(); i++) {
                        if (entry.getStringValue(i).toLowerCase().contains(searchText)) {
                            matchesSearch = true;
                            break;
                        }
                    }
                }
                
                // Check if matches category filter
                if (!"All Categories".equals(category)) {
                    matchesCategory = category.equals(entry.getStringValue(4)); // Category column
                }
                
                return matchesSearch && matchesCategory;
            }
        };
        
        sorter.setRowFilter(rowFilter);
    }
    
    private void addItemToBill() {
        try {
            String selected = (String) productComboBox.getSelectedItem();
            if (selected == null) {
                throw new GroceryStoreException("No product selected", 
                                              GroceryStoreException.INVALID_PRODUCT_CODE);
            }
            
            String productId = selected.split(" - ")[0];
            int quantity = (Integer) quantitySpinner.getValue();
            
            // Show progress
            updateStatus("Adding item to bill...", false);
            showProgress(true);
            
            // Use SwingWorker to perform database operations in background
            SwingWorker<Product, Void> worker = new SwingWorker<Product, Void>() {
                @Override
                protected Product doInBackground() throws Exception {
                    billingManager.addItemToBill(productId, quantity);
                    return inventoryManager.getProduct(productId);
                }
                
                @Override
                protected void done() {
                    try {
                        Product product = get();
                        
                        // Add to bill table
                        double subtotal = product.getPrice() * quantity;
                        billTableModel.addRow(new Object[] {
                            product.getName(),
                            product.getPrice(),
                            quantity,
                            subtotal
                        });
                        
                        // Update total
                        updateBillTotal();
                        
                        // Reset quantity spinner
                        quantitySpinner.setValue(1);
                        
                        updateStatus("Item added to bill", false);
                        showProgress(false);
                        
                    } catch (InterruptedException | ExecutionException e) {
                        handleException(e);
                        showProgress(false);
                    }
                }
            };
            
            worker.execute();
            
        } catch (Exception e) {
            handleException(e);
        }
    }
    
    private void updateBillTotal() {
        double total = 0;
        for (int i = 0; i < billTableModel.getRowCount(); i++) {
            total += (double) billTableModel.getValueAt(i, 3); // Subtotal column
        }
        totalLabel.setText("Total: $" + df.format(total) + ")");
    }
    
    private void refreshBillingProducts() {
        List<Product> products = billingManager.getProducts();
        
        productComboBox.removeAllItems();
        for (Product p : products) {
            productComboBox.addItem(p.getProductId() + " - " + p.getName() + " ($" + df.format(p.getPrice()) + ")");
        }
        
        JPanel selectionPanel = (JPanel) splitPane.getLeftComponent();
        JPanel quickSelectPanel = (JPanel) selectionPanel.getComponent(1);
        quickSelectPanel.removeAll();
        
        JPanel productGrid = new JPanel(new GridLayout(0, 2, 5, 5));
        for (int i = 0; i < Math.min(6, products.size()); i++) {
            Product product = products.get(i);
            JButton productButton = new JButton(product.getName());
            productButton.setFont(REGULAR_FONT);
            productButton.setIcon(createImageIcon("/icons/product.png", "Product"));
            productButton.setHorizontalAlignment(SwingConstants.LEFT);
            productButton.addActionListener(e -> {
                productComboBox.setSelectedItem(product.getProductId() + " - " + product.getName() + " ($" + df.format(product.getPrice()) + ")"); // Fixed: 'p' to 'product'
                quantitySpinner.setValue(1);
            });
            productGrid.add(productButton);
        }
        
        quickSelectPanel.add(productGrid, BorderLayout.CENTER);
        quickSelectPanel.revalidate();
        quickSelectPanel.repaint();
    }
    // FIXED: Generate Bill button now creates a PDF in Downloads folder
    private void generateBillPDF() {
    if (billTableModel.getRowCount() == 0) {
        showErrorDialog("No items in the bill", "Empty Bill");
        return;
    }
    
    try {
        // Show progress
        updateStatus("Generating bill...", false);
        showProgress(true);
        
        // Prepare bill data before database operations
        final List<Object[]> billItems = new ArrayList<>();
        final double billTotal = getCurrentBillTotal();
        
        for (int i = 0; i < billTableModel.getRowCount(); i++) {
            Object[] row = new Object[4];
            row[0] = billTableModel.getValueAt(i, 0); // Product name
            row[1] = billTableModel.getValueAt(i, 1); // Price
            row[2] = billTableModel.getValueAt(i, 2); // Quantity
            row[3] = billTableModel.getValueAt(i, 3); // Subtotal
            billItems.add(row);
        }
        
        // Use SwingWorker to perform database operations in background
        SwingWorker<Double, Void> worker = new SwingWorker<Double, Void>() {
            @Override
            protected Double doInBackground() throws Exception {
                return billingManager.generateBill();
            }
            
            @Override
            protected void done() {
                try {
                    double total = get();
                    
                    // Create PDF bill in a separate thread to avoid UI freezing
                    new Thread(() -> {
                        try {
                            // Create PDF bill
                            String userHome = System.getProperty("user.home");
                            String downloadsFolder = userHome + File.separator + "Downloads";
                            String fileName = "Bill_" + System.currentTimeMillis() + ".pdf";
                            String filePath = downloadsFolder + File.separator + fileName;
                            
                            createBillPDF(filePath, billItems, total);
                            
                            // Update UI on EDT
                            SwingUtilities.invokeLater(() -> {
                                // Clear bill table
                                billTableModel.setRowCount(0);
                                updateBillTotal();
                                
                                // Refresh inventory
                                refreshInventory();
                                
                                // Show success message
                                JOptionPane.showMessageDialog(frame,
                                    "Bill generated successfully!\nTotal Amount: $" + df.format(total) + 
                                    "\nPDF saved to: " + filePath,
                                    "Bill Generated", JOptionPane.INFORMATION_MESSAGE);
                                
                                updateStatus("Bill generated successfully", false);
                                showProgress(false);
                            });
                        } catch (Exception e) {
                            SwingUtilities.invokeLater(() -> {
                                handleException(e);
                                showProgress(false);
                            });
                        }
                    }).start();
                    
                } catch (InterruptedException | ExecutionException e) {
                    handleException(e);
                    showProgress(false);
                }
            }
        };
        
        worker.execute();
        
    } catch (Exception e) {
        handleException(e);
    }
}

// Add this helper method to calculate the current bill total
private double getCurrentBillTotal() {
    double total = 0;
    for (int i = 0; i < billTableModel.getRowCount(); i++) {
        total += (double) billTableModel.getValueAt(i, 3); // Subtotal column
    }
    return total;
}

// Update the createBillPDF method to accept bill items
private void createBillPDF(String filePath, List<Object[]> billItems, double total) {
    try {
        Document document = new Document();
        PdfWriter.getInstance(document, new FileOutputStream(filePath));
        document.open();
        
        // Add title - Define titleFont here
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
        Paragraph title = new Paragraph("Grocery Store Bill", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);
        
        // Add date
        Font dateFont = FontFactory.getFont(FontFactory.HELVETICA, 12);
        Paragraph date = new Paragraph("Date: " + dateFormat.format(new Date()), dateFont);
        date.setAlignment(Element.ALIGN_RIGHT);
        document.add(date);
        
        document.add(new Paragraph(" ")); // Add space
        
        // Create table
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
        table.setWidths(new float[] {3, 1, 1, 1.5f});
        
        // Add table headers
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
        PdfPCell cell;
        
        cell = new PdfPCell(new Phrase("Product", headerFont));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPadding(5);
        table.addCell(cell);
        
        cell = new PdfPCell(new Phrase("Price", headerFont));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPadding(5);
        table.addCell(cell);
        
        cell = new PdfPCell(new Phrase("Quantity", headerFont));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPadding(5);
        table.addCell(cell);
        
        cell = new PdfPCell(new Phrase("Subtotal", headerFont));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPadding(5);
        table.addCell(cell);
        
        // Add bill items
        Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 12);
        
        for (Object[] item : billItems) {
            table.addCell(new Phrase(item[0].toString(), cellFont));
            table.addCell(new Phrase("$" + df.format(item[1]), cellFont));
            table.addCell(new Phrase(item[2].toString(), cellFont));
            table.addCell(new Phrase("$" + df.format(item[3]), cellFont));
        }
        
        document.add(table);
        
        document.add(new Paragraph(" ")); // Add space
        
        // Add total
        Font totalFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);
        Paragraph totalParagraph = new Paragraph("Total: $" + df.format(total), totalFont);
        totalParagraph.setAlignment(Element.ALIGN_RIGHT);
        document.add(totalParagraph);
        
        // Add thank you message
        document.add(new Paragraph(" ")); // Add space
        Font thankYouFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.ITALIC);  // Changed "Helvetica" to FontFactory.HELVETICA
        Paragraph thankYou = new Paragraph("Thank you for shopping with us!", thankYouFont);
        thankYou.setAlignment(Element.ALIGN_CENTER);
        document.add(thankYou);
        
        document.close();
        
    } catch (DocumentException | IOException e) {
        throw new RuntimeException("Error creating PDF: " + e.getMessage(), e);
    }
}
    
    private void clearBill() {
        billTableModel.setRowCount(0);
        updateBillTotal();
        billingManager.clearBill();
        updateStatus("Bill cleared", false);
    }
    
    // FIXED: Add Product functionality
    private void showAddProductDialog() {
        JDialog dialog = new JDialog(frame, "Add New Product", true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(frame);
        dialog.setLayout(new BorderLayout());
        
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Product ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Product ID:"), gbc);
        
        JTextField productIdField = new JTextField(10);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        formPanel.add(productIdField, gbc);
        
        // Product Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        formPanel.add(new JLabel("Name:"), gbc);
        
        JTextField nameField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        formPanel.add(nameField, gbc);
        
        // Price
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.0;
        formPanel.add(new JLabel("Price:"), gbc);
        
        JTextField priceField = new JTextField(10);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.weightx = 1.0;
        formPanel.add(priceField, gbc);
        
        // Stock Quantity
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0.0;
        formPanel.add(new JLabel("Stock Quantity:"), gbc);
        
        JSpinner stockSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 1000, 1));
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.weightx = 1.0;
        formPanel.add(stockSpinner, gbc);
        
        // Category
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0.0;
        formPanel.add(new JLabel("Category:"), gbc);
        
        JComboBox<String> categoryCombo = new JComboBox<>(new String[]{"Grains", "Dairy", "Bakery", "Vegetables"});
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.weightx = 1.0;
        formPanel.add(categoryCombo, gbc);
        
        dialog.add(formPanel, BorderLayout.CENTER);
        
        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dialog.dispose());
        
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> {
            try {
                // Validate input
                String productId = productIdField.getText().trim();
                String name = nameField.getText().trim();
                String priceText = priceField.getText().trim();
                int stockQuantity = (Integer) stockSpinner.getValue();
                String category = (String) categoryCombo.getSelectedItem();
                
                if (productId.isEmpty() || name.isEmpty() || priceText.isEmpty()) {
                    throw new Exception("All fields are required");
                }
                
                double price = Double.parseDouble(priceText);
                
                // Show progress
                updateStatus("Adding new product...", false);
                showProgress(true);
                
                // Use SwingWorker to perform database operations in background
                SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
                    @Override
                    protected Boolean doInBackground() throws Exception {
                        Connection conn = null;
                        try {
                            conn = DatabaseConnection.getConnection();
                            
                            // Check if product ID already exists
                            String checkSql = "SELECT COUNT(*) FROM products WHERE product_id = ?";
                            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                            checkStmt.setString(1, productId);
                            ResultSet rs = checkStmt.executeQuery();
                            rs.next();
                            int count = rs.getInt(1);
                            
                            if (count > 0) {
                                throw new Exception("Product ID already exists");
                            }
                            
                            // Insert new product
                            String sql = "INSERT INTO products (product_id, name, price, stock_quantity, category) VALUES (?, ?, ?, ?, ?)";
                            PreparedStatement pstmt = conn.prepareStatement(sql);
                            pstmt.setString(1, productId);
                            pstmt.setString(2, name);
                            pstmt.setDouble(3, price);
                            pstmt.setInt(4, stockQuantity);
                            pstmt.setString(5, category);
                            
                            int rowsAffected = pstmt.executeUpdate();
                            return rowsAffected > 0;
                        } finally {
                            if (conn != null) {
                                conn.close();
                            }
                        }
                    }
                    
                    @Override
    protected void done() {
        try {
            boolean success = get();
            
            if (success) {
                Product newProduct = new Product(productId, name, price, stockQuantity, category);
                inventoryManager.addProduct(newProduct); // Add to cache
                SwingUtilities.invokeLater(() -> {
                    productComboBox.addItem(productId + " - " + name + " ($" + df.format(price) + ")");
                });
                JOptionPane.showMessageDialog(dialog, 
                    "Product added successfully:\n" +
                    "ID: " + productId + "\n" +
                    "Name: " + name + "\n" +
                    "Price: $" + price + "\n" +
                    "Stock: " + stockQuantity + "\n" +
                    "Category: " + category,
                    "Product Added", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
                refreshInventory(); // Optional: full refresh
                refreshBillingProducts(); // Optional: full refresh
            } else {
                showErrorDialog("Failed to add product", "Database Error");
            }
            
            updateStatus("Ready", false);
            showProgress(false);
            
        } catch (InterruptedException | ExecutionException e) {
            handleException(e);
            showProgress(false);
        }
    }
};
                
                worker.execute();
                
            } catch (NumberFormatException ex) {
                showErrorDialog("Invalid price format", "Input Error");
            } catch (Exception ex) {
                showErrorDialog(ex.getMessage(), "Input Error");
            }
        });
        
        buttonPanel.add(cancelButton);
        buttonPanel.add(saveButton);
        
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setVisible(true);
    } 
    // FIXED: Restock functionality
    private void showRestockDialog() {
        // Get selected product or show product selection dialog
        String productId = null;
        String productName = null;
        
        int selectedRow = productTable.getSelectedRow();
        if (selectedRow != -1) {
            productId = (String) productTable.getValueAt(selectedRow, 0);
            productName = (String) productTable.getValueAt(selectedRow, 1);
        } else {
            // No product selected, show product selection dialog
            List<Product> products = inventoryManager.getAllProducts();
            String[] productOptions = products.stream()
                .map(p -> p.getProductId() + " - " + p.getName())
                .toArray(String[]::new);
            
            String selected = (String) JOptionPane.showInputDialog(
                frame,
                "Select a product to restock:",
                "Restock Product",
                JOptionPane.QUESTION_MESSAGE,
                null,
                productOptions,
                productOptions[0]
            );
            
            if (selected == null) {
                return; // User canceled
            }
            
            productId = selected.split(" - ")[0];
            productName = selected.split(" - ")[1];
        }
        
        // Show restock dialog
        String quantityStr = JOptionPane.showInputDialog(
            frame,
            "Enter quantity to add for " + productName + ":",
            "Restock Product",
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (quantityStr == null || quantityStr.isEmpty()) {
            return; // User canceled
        }
        
        try {
            int quantity = Integer.parseInt(quantityStr);
            
            if (quantity <= 0) {
                showErrorDialog("Quantity must be greater than zero", "Input Error");
                return;
            }
            
            // Restock product
            inventoryManager.restockProduct(productId, quantity);
            
            JOptionPane.showMessageDialog(
                frame,
                "Successfully restocked " + quantity + " units of " + productName,
                "Restock Successful",
                JOptionPane.INFORMATION_MESSAGE
            );
            
            refreshInventory();
            
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid quantity format", "Input Error");
        } catch (Exception e) {
            handleException(e);
        }
    }
    
    // FIXED: Logout functionality
    private void logout() {
        int option = JOptionPane.showConfirmDialog(
            frame,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (option == JOptionPane.YES_OPTION) {
            frame.dispose();
            JOptionPane.showMessageDialog(
                null,
                "You have been logged out successfully.",
                "Logout Successful",
                JOptionPane.INFORMATION_MESSAGE
            );
            System.exit(0);
        }
    }
    
    // FIXED: Generate Sales Report
    private void generateSalesReport() {
        updateStatus("Generating sales report...", false);
        showProgress(true);
        
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                // Simulate data processing
                Thread.sleep(1000);
                return null;
            }
            
            @Override
            protected void done() {
                // Clear previous chart
                salesChartPanel.removeAll();
                
                // Create a simple bar chart for sales data
                JPanel chartPanel = new JPanel(new BorderLayout());
                chartPanel.setBackground(Color.WHITE);
                
                // Create a panel for the bar chart
                JPanel barChart = new JPanel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        Graphics2D g2d = (Graphics2D) g;
                        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        
                        int width = getWidth();
                        int height = getHeight();
                        int barWidth = width / 8;
                        int maxBarHeight = height - 50;
                        
                        // Sample data - in a real app, this would come from the database
                        int[] salesData = {120, 150, 80, 200, 170, 90, 110};
                        String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
                        int maxSales = 200;
                        
                        // Draw axes
                        g2d.setColor(Color.BLACK);
                        g2d.drawLine(40, height - 30, width - 20, height - 30); // X-axis
                        g2d.drawLine(40, 20, 40, height - 30); // Y-axis
                        
                        // Draw bars
                        for (int i = 0; i < salesData.length; i++) {
                            int barHeight = (int) ((double) salesData[i] / maxSales * maxBarHeight);
                            int x = 50 + i * (barWidth + 10);
                            int y = height - 30 - barHeight;
                            
                            // Draw bar
                            g2d.setColor(new Color(66, 165, 245, 200));
                            g2d.fillRect(x, y, barWidth, barHeight);
                            
                            // Draw border
                            g2d.setColor(new Color(25, 118, 210));
                            g2d.drawRect(x, y, barWidth, barHeight);
                            
                            // Draw value
                            g2d.setColor(Color.BLACK);
                            g2d.drawString(String.valueOf(salesData[i]), x + barWidth/2 - 10, y - 5);
                            
                            // Draw day label
                            g2d.drawString(days[i], x + barWidth/2 - 10, height - 10);
                        }
                        
                        // Draw Y-axis labels
                        for (int i = 0; i <= 5; i++) {
                            int value = i * (maxSales / 5);
                            int y = height - 30 - (int) ((double) value / maxSales * maxBarHeight);
                            g2d.drawString(String.valueOf(value), 10, y + 5);
                            g2d.drawLine(35, y, 45, y); // Tick mark
                        }
                        
                        // Draw title
                        g2d.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 16));
                        g2d.drawString("Weekly Sales Report", width/2 - 80, 15);
                    }
                };
                
                chartPanel.add(barChart, BorderLayout.CENTER);
                
                // Add a legend
                JPanel legendPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
                legendPanel.setBackground(Color.WHITE);
                
                JLabel legendLabel = new JLabel("Sales in $");
                legendLabel.setFont(REGULAR_FONT);
                legendPanel.add(legendLabel);
                
                chartPanel.add(legendPanel, BorderLayout.SOUTH);
                
                // Add the chart to the panel
                salesChartPanel.add(chartPanel, BorderLayout.CENTER);
                salesChartPanel.revalidate();
                salesChartPanel.repaint();
                
                updateStatus("Sales report generated successfully", false);
                showProgress(false);
            }
        };
        
        worker.execute();
    }
    
    // FIXED: View Inventory Report
    private void viewInventoryReport() {
        updateStatus("Generating inventory report...", false);
        showProgress(true);
        
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                // Simulate data processing
                Thread.sleep(1000);
                return null;
            }
            
            @Override
            protected void done() {
                // Clear previous chart
                inventoryChartPanel.removeAll();
                
                // Create a simple pie chart for inventory data
                JPanel chartPanel = new JPanel(new BorderLayout());
                chartPanel.setBackground(Color.WHITE);
                
                // Create a panel for the pie chart
                JPanel pieChart = new JPanel() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        Graphics2D g2d = (Graphics2D) g;
                        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        
                        int width = getWidth();
                        int height = getHeight();
                        int pieSize = Math.min(width, height) - 100;
                        int x = (width - pieSize) / 2;
                        int y = (height - pieSize) / 2;
                        
                        // Sample data - in a real app, this would come from the database
                        int[] stockData = {100, 50, 30, 45};
                        String[] categories = {"Grains", "Dairy", "Bakery", "Vegetables"};
                        Color[] colors = {
                            new Color(66, 165, 245), // Blue
                            new Color(76, 175, 80),  // Green
                            new Color(255, 152, 0),  // Orange
                            new Color(244, 67, 54)   // Red
                        };
                        
                        int total = 0;
                        for (int value : stockData) {
                            total += value;
                        }
                        
                        // Draw pie chart
                        int startAngle = 0;
                        for (int i = 0; i < stockData.length; i++) {
                            int arcAngle = (int) Math.round(360.0 * stockData[i] / total);
                            
                            g2d.setColor(colors[i]);
                            g2d.fillArc(x, y, pieSize, pieSize, startAngle, arcAngle);
                            
                            // Draw border
                            g2d.setColor(Color.WHITE);
                            g2d.drawArc(x, y, pieSize, pieSize, startAngle, arcAngle);
                            
                            startAngle += arcAngle;
                        }
                        
                        // Draw title
                        g2d.setColor(Color.BLACK);
                        g2d.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 16));
                        g2d.drawString("Inventory by Category", width/2 - 100, 20);
                        
                        // Draw legend
                        int legendX = width - 150;
                        int legendY = 50;
                        
                        for (int i = 0; i < categories.length; i++) {
                            g2d.setColor(colors[i]);
                            g2d.fillRect(legendX, legendY + i*20, 15, 15);
                            
                            g2d.setColor(Color.BLACK);
                            g2d.setFont(REGULAR_FONT);
                            g2d.drawString(categories[i] + " (" + stockData[i] + ")", legendX + 20, legendY + i*20 + 12);
                        }
                    }
                };
                
                chartPanel.add(pieChart, BorderLayout.CENTER);
                
                // Add the chart to the panel
                inventoryChartPanel.add(chartPanel, BorderLayout.CENTER);
                inventoryChartPanel.revalidate();
                inventoryChartPanel.repaint();
                
                updateStatus("Inventory report generated successfully", false);
                showProgress(false);
            }
        };
        
        worker.execute();
    }
    
    // FIXED: Export Inventory to CSV
    private void exportInventoryToCSV() {
        updateStatus("Exporting inventory to CSV...", false);
        showProgress(true);
        
        SwingWorker<String, Void> worker = new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws Exception {
                // Get the selected category
                String selectedCategory = (String) reportCategoryCombo.getSelectedItem();
                
                // Get inventory data
                List<Product> products = inventoryManager.getAllProducts();
                
                // Filter by category if needed
                if (!"All Categories".equals(selectedCategory)) {
                    products = products.stream()
                        .filter(p -> selectedCategory.equals(p.getCategory()))
                        .collect(java.util.stream.Collectors.toList());
                }
                
                // Create CSV file in Downloads folder
                String userHome = System.getProperty("user.home");
                String downloadsFolder = userHome + File.separator + "Downloads";
                String fileName = "Inventory_" + System.currentTimeMillis() + ".csv";
                String filePath = downloadsFolder + File.separator + fileName;
                
                // Write to CSV
                try (PrintWriter writer = new PrintWriter(new File(filePath))) {
                    // Write header
                    writer.println("Product ID,Name,Price,Stock Quantity,Category");
                    
                    // Write data
                    for (Product product : products) {
                        writer.println(
                            product.getProductId() + "," +
                            product.getName() + "," +
                            product.getPrice() + "," +
                            product.getStockQuantity() + "," +
                            product.getCategory()
                        );
                    }
                }
                
                return filePath;
            }
            
            @Override
            protected void done() {
                try {
                    String filePath = get();
                    
                    JOptionPane.showMessageDialog(
                        frame,
                        "Inventory exported successfully to:\n" + filePath,
                        "Export Successful",
                        JOptionPane.INFORMATION_MESSAGE
                    );
                    
                    updateStatus("Inventory exported to CSV successfully", false);
                    showProgress(false);
                    
                } catch (InterruptedException | ExecutionException e) {
                    handleException(e);
                    showProgress(false);
                }
            }
        };
        
        worker.execute();
    }
    
    private void handleException(Exception e) {
        String errorMessage;
        String errorTitle;
        
        if (e instanceof GroceryStoreException) {
            GroceryStoreException gse = (GroceryStoreException) e;
            errorMessage = gse.getMessage();
            errorTitle = gse.getErrorType();
            updateStatus("Error: " + errorTitle + " - " + errorMessage, true);
        } else {
            errorMessage = "Unexpected error: " + e.getMessage();
            errorTitle = "System Error";
            updateStatus("System Error: " + e.getMessage(), true);
        }
        
        showErrorDialog(errorMessage, errorTitle);
        e.printStackTrace();
    }
    
    private void showErrorDialog(String message, String title) {
        JOptionPane.showMessageDialog(frame, message, title, JOptionPane.ERROR_MESSAGE);
    }
    
    private void updateStatus(String message, boolean isError) {
        statusLabel.setText(message);
        statusLabel.setForeground(isError ? ERROR_COLOR : PRIMARY_COLOR);
    }
    
    private void showProgress(boolean visible) {
        progressBar.setVisible(visible);
        if (visible) {
            progressBar.setIndeterminate(true);
        } else {
            progressBar.setIndeterminate(false);
        }
    }
    
    public static void main(String[] args) {
        try {
            // Set look and feel to system default
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new EnhancedGroceryStoreGUI());
    }
}
