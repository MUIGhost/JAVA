package GroceryStore;

public class GroceryStoreException extends RuntimeException {
    
    public static final int INVALID_PRODUCT_CODE = 1;
    public static final int OUT_OF_STOCK = 2;
    public static final int DATABASE_CONNECTION_ERROR = 3;
    public static final int TRANSACTION_ERROR = 4;
    
    private int errorCode;
    
    public GroceryStoreException(String message, int errorCode) {
        super(message);
        this.errorCode = errorCode;
    }
    
    public GroceryStoreException(String message, Throwable cause, int errorCode) {
        super(message, cause);
        this.errorCode = errorCode;
    }
    
    public int getErrorCode() {
        return errorCode;
    }
    
    public String getErrorType() {
        switch (errorCode) {
            case INVALID_PRODUCT_CODE:
                return "Invalid Product Code";
            case OUT_OF_STOCK:
                return "Out of Stock";
            case DATABASE_CONNECTION_ERROR:
                return "Database Connection Error";
            case TRANSACTION_ERROR:
                return "Transaction Error";
            default:
                return "Unknown Error";
        }
    }
}
