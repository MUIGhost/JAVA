package GroceryStore;

import java.sql.*;
import java.util.*;

public class InventoryManager {
    private Map<String, Product> productInventory;
    
    public InventoryManager() {
        productInventory = new HashMap<>();
        loadInventory();
    }
    
    private void loadInventory() {
        String sql = "SELECT * FROM products";
        Connection conn = null;
        
        try {
            conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Product product = new Product(
                    rs.getString("product_id"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getInt("stock_quantity"),
                    rs.getString("category")
                );
                productInventory.put(product.getProductId(), product);
            }
        } catch (SQLException e) {
            throw new GroceryStoreException("Failed to load inventory: " + e.getMessage(), 
                                           e, GroceryStoreException.DATABASE_CONNECTION_ERROR);
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("Error closing connection: " + e.getMessage());
            }
        }
    }
    
    public Product getProduct(String productId) {
        Product product = productInventory.get(productId);
        if (product == null) {
            throw new GroceryStoreException("Product with ID " + productId + " not found", 
                                           GroceryStoreException.INVALID_PRODUCT_CODE);
        }
        return product;
    }
    
    public boolean checkStock(String productId, int quantity) {
        Product product = getProduct(productId);
        return product.getStockQuantity() >= quantity;
    }
    
    public void updateStock(String productId, int quantity) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            
            // First check if we have enough stock
            Product product = getProduct(productId);
            if (product.getStockQuantity() < quantity) {
                throw new GroceryStoreException("Insufficient stock for product: " + product.getName() + 
                                              ". Available: " + product.getStockQuantity(), 
                                              GroceryStoreException.OUT_OF_STOCK);
            }
            
            // Update database
            String sql = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, quantity);
            pstmt.setString(2, productId);
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected == 0) {
                throw new GroceryStoreException("Failed to update stock for product: " + productId, 
                                               GroceryStoreException.TRANSACTION_ERROR);
            }
            
            // Update local cache
            product.setStockQuantity(product.getStockQuantity() - quantity);
            
        } catch (SQLException e) {
            throw new GroceryStoreException("Database error while updating stock: " + e.getMessage(), 
                                           e, GroceryStoreException.DATABASE_CONNECTION_ERROR);
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("Error closing connection: " + e.getMessage());
            }
        }
    }
    
    public void restockProduct(String productId, int quantity) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            
            String sql = "UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, quantity);
            pstmt.setString(2, productId);
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected == 0) {
                throw new GroceryStoreException("Failed to restock product: " + productId, 
                                               GroceryStoreException.TRANSACTION_ERROR);
            }
            
            // Update local cache
            Product product = getProduct(productId);
            product.setStockQuantity(product.getStockQuantity() + quantity);
            
        } catch (SQLException e) {
            throw new GroceryStoreException("Database error while restocking: " + e.getMessage(), 
                                           e, GroceryStoreException.DATABASE_CONNECTION_ERROR);
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("Error closing connection: " + e.getMessage());
            }
        }
    }
    
    public List<Product> getAllProducts() {
        return new ArrayList<>(productInventory.values());
    }
    
    public List<Product> getLowStockProducts(int threshold) {
        List<Product> lowStockProducts = new ArrayList<>();
        for (Product product : productInventory.values()) {
            if (product.getStockQuantity() <= threshold) {
                lowStockProducts.add(product);
            }
        }
        return lowStockProducts;
    }
    
    public void refreshInventory() {
        productInventory.clear();
        loadInventory();
    }
    
    // New method to add a product to the cache
    public void addProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        if (productInventory.containsKey(product.getProductId())) {
            throw new GroceryStoreException("Product with ID " + product.getProductId() + " already exists in inventory",
                                           GroceryStoreException.INVALID_PRODUCT_CODE);
        }
        productInventory.put(product.getProductId(), product);
    }
}