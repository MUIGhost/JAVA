package GroceryStore;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/grocery_store_db";
    private static final String USER = "root";
    private static final String PASSWORD = "password";  // Updated to your password
    
    private static final int MAX_RETRY_ATTEMPTS = 3;
    private static final long RETRY_DELAY_MS = 2000; // 2 seconds

    public static Connection getConnection() throws SQLException {
        SQLException lastException = null;
        
        for (int attempt = 1; attempt <= MAX_RETRY_ATTEMPTS; attempt++) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            
                // Add connection properties to improve performance and handle timeouts better
                Properties props = new Properties();
                props.setProperty("user", USER);
                props.setProperty("password", PASSWORD);
                props.setProperty("connectTimeout", "5000"); // 5 second connection timeout
                props.setProperty("socketTimeout", "30000"); // 30 second socket timeout
                props.setProperty("autoReconnect", "true");
                props.setProperty("useSSL", "false"); // Disable SSL for local development
            
                Connection conn = DriverManager.getConnection(URL, props);
            
                // Test the connection
                if (conn.isValid(5)) { // 5 second timeout
                    // Set some default connection properties
                    conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
                    return conn;
                }
            } catch (ClassNotFoundException e) {
                throw new SQLException("MySQL JDBC Driver not found.", e);
            } catch (SQLException e) {
                lastException = e;
                System.err.println("Connection attempt " + attempt + " failed: " + e.getMessage());
            
                if (attempt < MAX_RETRY_ATTEMPTS) {
                    try {
                        Thread.sleep(RETRY_DELAY_MS);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }
        
        // If we get here, all attempts failed
        throw new SQLException("Failed to establish database connection after " + 
                              MAX_RETRY_ATTEMPTS + " attempts.", lastException);
    }
    
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && conn.isValid(5);
        } catch (SQLException e) {
            return false;
        }
    }
}
