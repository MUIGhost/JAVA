USE grocery_store_db;

INSERT INTO products (product_id, name, price, stock_quantity, category) VALUES
('P001', 'Rice 1kg', 400, 100, 'Grains'),
('P002', 'Milk 1L', 80, 50, 'Dairy'),
('P003', 'Bread', 200, 30, 'Bakery'),
('P004', 'Eggs 12pk', 150, 40, 'Dairy'),
('P005', 'Tomatoes 1kg', 300, 45, 'Vegetables');