#!/bin/bash

# Create database
echo "Creating database userdb..."
mysql -u root -p <<EOF
CREATE DATABASE IF NOT EXISTS userdb;
USE userdb;
$(cat src/main/resources/schema.sql)
EOF

echo "Database setup complete!"
