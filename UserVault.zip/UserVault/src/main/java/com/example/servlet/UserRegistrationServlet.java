package com.example.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.sql.*;
import java.util.regex.Pattern;

@WebServlet("/register")
public class UserRegistrationServlet extends HttpServlet {
    // Email validation regex pattern
    private static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@(.+)$";
    private static final String DB_URL = "jdbc:mysql://localhost:3306/userdb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        // Input validation
        if (!validateInputs(username, email, password)) {
            sendErrorResponse(response, "Invalid input parameters");
            return;
        }

        try {
            // Check if user exists
            if (userExists(username, email)) {
                sendErrorResponse(response, "User already exists");
                return;
            }

            // Save user to database
            saveUser(username, email, password);
            
            // Send success response
            response.setContentType("application/json");
            response.getWriter().write("{\"status\": \"success\", \"message\": \"User registered successfully\"}");

        } catch (SQLException e) {
            sendErrorResponse(response, "Database error: " + e.getMessage());
        }
    }

    private boolean validateInputs(String username, String email, String password) {
        if (username == null || username.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            password == null || password.length() < 6) {
            return false;
        }
        
        // Validate email format
        return Pattern.compile(EMAIL_REGEX).matcher(email).matches();
    }

    private boolean userExists(String username, String email) throws SQLException {
        String query = "SELECT COUNT(*) FROM users WHERE username = ? OR email = ?";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, email);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    private void saveUser(String username, String email, String password) throws SQLException {
        String query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, email);
            pstmt.setString(3, password); // In production, hash the password before storing
            
            pstmt.executeUpdate();
        }
    }

    private void sendErrorResponse(HttpServletResponse response, String message) throws IOException {
        response.setContentType("application/json");
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        response.getWriter().write("{\"status\": \"error\", \"message\": \"" + message + "\"}");
    }
}