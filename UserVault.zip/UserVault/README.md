# UserVault

A simple user registration system built with Java Servlets and MySQL.

## Description

UserVault is a web application that allows users to register with a username, email, and password. The application validates user input and stores the information securely in a MySQL database.

## Features

- User registration with validation
- Email format validation
- Duplicate user detection
- Responsive UI

## Prerequisites

- Java 11 or higher
- Maven 3.6 or higher
- MySQL 5.7 or higher

## Installation and Setup

### 1. Clone the repository

```bash
git clone https://github.com/MUIGhost/UserVault.git
cd UserVault
```

### 2. Set up the database

Create a MySQL database and run the schema script:

```bash
# Log in to MySQL
mysql -u root -p

# Create the database
CREATE DATABASE userdb;
USE userdb;

# Exit MySQL
exit;

# Import the schema (alternatively, you can run the setup_db.sh script)
mysql -u root -p userdb < src/main/resources/schema.sql
```

### 3. Configure database connection

The default database configuration in `UserRegistrationServlet.java` is:

```java
private static final String DB_URL = "jdbc:mysql://localhost:3306/userdb";
private static final String DB_USER = "root";
private static final String DB_PASSWORD = "password";
```

Update these values if your MySQL configuration is different.

## Running the Application

### Using Maven

```bash
# Build the project
mvn clean package

# Run with Tomcat Maven plugin
mvn tomcat7:run
```

The application will be available at: http://localhost:8090/uservault/

## Usage

1. Open your browser and navigate to http://localhost:8090/uservault/
2. Fill out the registration form with a username, email, and password
3. Click the "Register" button
4. You will receive a success message if registration is successful

## License

MIT License

Copyright (c) 2025 Shriyog More

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Author

- **Shriyog More** - [GitHub](https://github.com/MUIGhost)

## Acknowledgments

- Java Servlet API
- MySQL Database
- Apache Tomcat
