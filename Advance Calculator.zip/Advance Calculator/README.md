# Advanced Calculator

A client-server calculator application that evaluates mathematical expressions.

## Features

- Client-server architecture
- Evaluates complex mathematical expressions
- Supports basic operations: addition, subtraction, multiplication, division, and exponentiation
- Handles parentheses for expression grouping

## How to Run

### Prerequisites

- Java Development Kit (JDK) 8 or higher

### Compilation

Compile all Java files with the following command:

```bash
mkdir -p target/classes && javac -d target/classes src/main/java/calculator/*.java
```

### Running the Application

1. Start the server:

```bash
java -cp target/classes calculator.CalculatorServer
```

2. In a separate terminal, run the client:

```bash
java -cp target/classes calculator.CalculatorClient
```

3. Enter a mathematical expression when prompted (e.g., `3+2*4-1`)

4. The server will evaluate the expression and return the result

## Project Structure

- `CalculatorClient.java`: Connects to the server, sends expressions, and displays results
- `CalculatorServer.java`: Listens for client connections and processes expressions
- `Calculator.java`: Contains the logic to evaluate mathematical expressions

## License

MIT License

Copyright (c) 2023 Shriyog More

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Author

- **Shriyog More** - [GitHub](https://github.com/MUIGhost)
