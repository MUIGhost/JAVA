package calculator;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class CalculatorClient {
    private static final String HOST = "localhost";
    private static final int PORT = 5000;
    
    public static void main(String[] args) {
        try (Socket socket = new Socket(HOST, PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             Scanner scanner = new Scanner(System.in)) {
            
            System.out.println("Connected to Calculator Server");
            System.out.println("Enter mathematical expression (e.g., 3+2*4-1):");
            
            String expression = scanner.nextLine();
            out.println(expression);
            
            String response = in.readLine();
            System.out.println(response);
            
        } catch (UnknownHostException e) {
            System.err.println("Unknown host: " + HOST);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection to " + HOST);
            System.exit(1);
        }
    }
}