import java.sql.*;

public class EmployeeDB {
    static final String URL = "jdbc:mysql://localhost:3306/correctDBName"; // Replace with your DB name
    static final String USER = "root";
    static final String PASS = "password";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            System.out.println("Connected to database");
            // Clear table for fresh start (optional)
            try (Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("TRUNCATE TABLE Employee");
            }
            insertEmployee(conn, "Sanskruti", "Manager", 70000);
            System.out.println("Inserted Sanskruti");
            insertEmployee(conn, "Maitrey", "Director", 90000);
            System.out.println("Inserted Maitrey");
            insertEmployee(conn, "Shri", "Clerk", 50000);
            System.out.println("Inserted Shri");
            getEmployeesAboveAvgSalary(conn);
            updatePosition(conn, 1, "Senior Manager");
            System.out.println("Updated Sanskruti's position to Senior Manager");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void insertEmployee(Connection conn, String name, String pos, double salary) throws SQLException {
        String sql = "INSERT INTO Employee (name, position, salary) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, pos);
            ps.setDouble(3, salary);
            ps.executeUpdate();
        }
    }

    static void getEmployeesAboveAvgSalary(Connection conn) throws SQLException {
        String avgSql = "SELECT AVG(salary) FROM Employee";
        try (Statement avgStmt = conn.createStatement(); ResultSet avgRs = avgStmt.executeQuery(avgSql)) {
            avgRs.next();
            double avgSalary = avgRs.getDouble(1);
            System.out.println("Average salary: " + avgSalary);
        }
        String sql = "SELECT * FROM Employee WHERE salary > (" + avgSql + ")";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("Fetching employees above average salary:");
            while (rs.next()) {
                System.out.println(rs.getString("name") + " - " + rs.getDouble("salary"));
            }
        }
    }

    static void updatePosition(Connection conn, int id, String newPosition) throws SQLException {
        String sql = "UPDATE Employee SET position = ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newPosition);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }
}