import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/students")
public class StudentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/DB", "root", "password");
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM Students WHERE gpa >= 3.5");
             ResultSet rs = ps.executeQuery()) {

            out.println("<table><tr><th>ID</th><th>Name</th><th>GPA</th></tr>");
            while (rs.next()) out.println("<tr><td>" + rs.getInt("id") + "</td><td>" +
                    rs.getString("name") + "</td><td>" + rs.getDouble("gpa") + "</td></tr>");
            out.println("</table>");

        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }
}
